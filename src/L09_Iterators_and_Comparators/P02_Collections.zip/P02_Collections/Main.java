package L09_Iterators_and_Comparators.P02_Collections;

public class Main {

    private static final Engine ENGINE = new Engine();

    public static void main(String[] args) {

        ENGINE.run();
    }
}
