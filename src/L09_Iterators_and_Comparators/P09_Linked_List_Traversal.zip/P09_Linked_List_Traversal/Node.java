package L09_Iterators_and_Comparators.P09_Linked_List_Traversal;

public class Node {
    int value;
    Node prev;
    Node next;

    Node(int value){
        this.value = value;
        this.prev = null;
        this.next = null;
    }
}
