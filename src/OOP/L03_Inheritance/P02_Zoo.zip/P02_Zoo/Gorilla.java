package P02_Zoo;

public class Gorilla extends Mammal{
    public Gorilla(String name) {
        super(name);
    }
}
